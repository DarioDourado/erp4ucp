-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: erp4udario
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_locks_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `family`
--

DROP TABLE IF EXISTS `family`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `family` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `family` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `family_family_unique` (`family`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `family`
--

LOCK TABLES `family` WRITE;
/*!40000 ALTER TABLE `family` DISABLE KEYS */;
INSERT INTO `family` VALUES (1,'Frutas','2026-04-19 15:20:02','2026-04-19 15:55:54'),(2,'Sumos','2026-04-19 15:56:07',NULL),(3,'GERAL','2026-05-20 19:56:43','2026-05-20 19:56:43');
/*!40000 ALTER TABLE `family` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `goodsreceiptc`
--

DROP TABLE IF EXISTS `goodsreceiptc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `goodsreceiptc` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `gRNumber` int NOT NULL,
  `supplierCode` int NOT NULL,
  `purchaseOrderId` bigint unsigned DEFAULT NULL,
  `purchaseOrderNumber` int DEFAULT NULL,
  `supplierGuideNumber` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gRDate` date DEFAULT NULL,
  `gRObservation` text COLLATE utf8mb4_unicode_ci,
  `totalNet` decimal(14,2) NOT NULL DEFAULT '0.00',
  `totalTax` decimal(14,2) NOT NULL DEFAULT '0.00',
  `totalGross` decimal(14,2) NOT NULL DEFAULT '0.00',
  `status` tinyint NOT NULL DEFAULT '1' COMMENT '0 = Anulado, 1 = Emitido',
  `created_by` int DEFAULT NULL,
  `updated_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `goodsreceiptc_grnumber_unique` (`gRNumber`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `goodsreceiptc`
--

LOCK TABLES `goodsreceiptc` WRITE;
/*!40000 ALTER TABLE `goodsreceiptc` DISABLE KEYS */;
INSERT INTO `goodsreceiptc` VALUES (2,1,11,1,1,'1234','2026-05-14',NULL,2.75,0.64,3.39,1,3,3,'2026-05-14 07:52:45','2026-05-14 07:58:22'),(3,2,11,1,1,'1235','2026-05-14',NULL,5.50,1.27,6.77,1,3,NULL,'2026-05-14 08:01:54','2026-05-14 08:01:54'),(4,3,999,2,2,'4325','2026-05-14',NULL,4.00,0.92,4.92,1,3,NULL,'2026-05-14 10:40:26','2026-05-14 10:40:26');
/*!40000 ALTER TABLE `goodsreceiptc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `goodsreceiptd`
--

DROP TABLE IF EXISTS `goodsreceiptd`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `goodsreceiptd` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `goodsReceiptId` bigint unsigned NOT NULL,
  `purchaseOrderDId` bigint unsigned NOT NULL,
  `productCode` varchar(21) COLLATE utf8mb4_unicode_ci NOT NULL,
  `productUnit` varchar(25) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `taxRateCode` int NOT NULL,
  `orderedQuantity` double NOT NULL DEFAULT '0',
  `previousDeliveredQuantity` double NOT NULL DEFAULT '0',
  `deliveryQuantity` double NOT NULL DEFAULT '0',
  `pendingQuantity` double NOT NULL DEFAULT '0',
  `unitPrice` double NOT NULL DEFAULT '0',
  `lineNet` double NOT NULL DEFAULT '0',
  `lineTax` double NOT NULL DEFAULT '0',
  `status` tinyint NOT NULL DEFAULT '1' COMMENT '0 = Anulado, 1 = Emitido',
  `created_by` int DEFAULT NULL,
  `updated_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `goodsreceiptd`
--

LOCK TABLES `goodsreceiptd` WRITE;
/*!40000 ALTER TABLE `goodsreceiptd` DISABLE KEYS */;
INSERT INTO `goodsreceiptd` VALUES (3,2,1,'P002','L',23,10,0,1,9,1.5,1.5,0.35,1,3,NULL,'2026-05-14 07:58:22','2026-05-14 07:58:22'),(4,2,2,'P002','L',23,50,0,1,49,1.25,1.25,0.29,1,3,NULL,'2026-05-14 07:58:22','2026-05-14 07:58:22'),(5,3,1,'P002','L',23,10,1,2,7,1.5,3,0.69,1,3,NULL,'2026-05-14 08:01:54','2026-05-14 08:01:54'),(6,3,2,'P002','L',23,50,1,2,47,1.25,2.5,0.58,1,3,NULL,'2026-05-14 08:01:54','2026-05-14 08:01:54'),(7,4,3,'P001','L',23,10,0,1,9,2,2,0.46,1,3,NULL,'2026-05-14 10:40:26','2026-05-14 10:40:26'),(8,4,4,'P002','L',23,10,0,2,8,1,2,0.46,1,3,NULL,'2026-05-14 10:40:26','2026-05-14 10:40:26');
/*!40000 ALTER TABLE `goodsreceiptd` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_reserved_at_available_at_index` (`queue`,`reserved_at`,`available_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2019_08_19_000000_create_failed_jobs_table',1),(4,'2019_12_14_000001_create_personal_access_tokens_table',1),(5,'2026_03_20_093907_create_postal_codes_table',2),(6,'0001_01_01_000000_create_users_table',3),(7,'0001_01_01_000001_create_cache_table',4),(8,'0001_01_01_000002_create_jobs_table',5),(9,'2026_03_13_160221_create_password_resets_table',5),(10,'2026_04_19_100001_create_supplier_table',6),(11,'2026_04_19_100002_create_family_table',6),(12,'2026_04_19_100003_create_unit_measure_table',6),(13,'2026_04_19_100004_create_tax_rate_table',6),(14,'2026_04_19_095831_create_families_table',7),(15,'2026_04_19_095831_create_suppliers_table',7),(16,'2026_04_19_095831_create_tax_rates_table',7),(17,'2026_04_19_095831_create_unit_measures_table',7),(18,'2026_04_19_103000_fix_supplier_address_column',8),(19,'2026_04_19_110500_rename_address_to_address1_in_supplier_table',9),(20,'2026_04_19_111408_adicionar_campo_tabela_supplier',10),(21,'2026_04_19_111956_alterar_campo_n_i_f_tabela_supplier',11),(22,'2026_04_19_163000_make_nif_nullable_in_supplier_table',12),(23,'2026_05_04_120000_create_article_table',13),(24,'2026_03_26_224120_create_products_table',14),(25,'2026_03_26_233038_adicionar_campo_tabela_suppliertax_rate_code',14),(26,'2026_04_01_111024_create_purchase_order_c_s_table',14),(27,'2026_04_01_111033_create_purchase_order_d_s_table',14),(28,'2026_04_01_150500_add_totals_to_purchase_order_c_table',14),(29,'2026_04_02_090000_create_goods_receipt_c_s_table',14),(30,'2026_04_02_090100_create_goods_receipt_d_s_table',14),(31,'2026_04_02_090200_create_stock_movements_table',14),(32,'2026_06_04_000000_increase_product_description_length',15);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `postalcode`
--

DROP TABLE IF EXISTS `postalcode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `postalcode` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `postalCode` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint NOT NULL DEFAULT '1',
  `created_by` int DEFAULT NULL,
  `updated_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `postalcode_postalcode_unique` (`postalCode`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `postalcode`
--

LOCK TABLES `postalcode` WRITE;
/*!40000 ALTER TABLE `postalcode` DISABLE KEYS */;
INSERT INTO `postalcode` VALUES (1,'8150-156','São Brás de Alportel',1,1,1,'2026-03-27 22:39:48','2026-03-27 22:39:56'),(3,'8000-325','Faro',1,1,NULL,'2026-03-27 22:40:28',NULL),(4,'8200','Loulé',1,2,NULL,'2026-04-24 18:35:46',NULL),(5,'2700-001','Amadora',1,1,NULL,'2026-05-14 08:22:48','2026-05-14 08:22:48');
/*!40000 ALTER TABLE `postalcode` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(21) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `family` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unit` varchar(25) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `taxRateCode` int NOT NULL,
  `status` varchar(25) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `updated_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_code_unique` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=177 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES (1,'P001','Sumox Laranja 0.5L','upload/product/1864564839538204.jpg','Sumos','L',23,NULL,3,NULL,'2026-05-07 19:59:58',NULL),(2,'P002','Água Zizz 1L','upload/product/1864564859214500.jpg','Sumos','L',23,NULL,3,NULL,'2026-05-07 20:00:17',NULL),(166,'ART-1','Leite UHT Meio-gordo IL (Mimosa',NULL,'GERAL','UN',6,'1',3,NULL,'2026-06-04 17:37:07','2026-06-04 17:37:07'),(167,'ART-2','logurte Natural 125g (Activia',NULL,'GERAL','UN',6,'1',3,NULL,'2026-06-04 17:37:08','2026-06-04 17:37:08'),(168,'ART-3','Manteiga 250g Presidente',NULL,'GERAL','UN',6,'1',3,NULL,'2026-06-04 17:37:08','2026-06-04 17:37:08'),(169,'ART-4','Queijo Flamengo fatiado 200g (Saloio',NULL,'GERAL','UN',6,'1',3,NULL,'2026-06-04 17:37:08','2026-06-04 17:37:08'),(170,'ART-5','Natas para Culinária 200ml (Parmalat',NULL,'GERAL','UN',6,'1',3,NULL,'2026-06-04 17:37:08','2026-06-04 17:37:08'),(171,'ART-6','Pão de Forma Integral 500g (Bimbo',NULL,'GERAL','UN',6,'1',3,NULL,'2026-06-04 17:41:49','2026-06-04 17:41:49'),(172,'ART-7','Croissant de Manteiga unidade (congelado',NULL,'GERAL','UN',6,'1',3,NULL,'2026-06-04 17:41:49','2026-06-04 17:41:49'),(173,'ART-8','Bolo de Mel da Madeira 400g',NULL,'GERAL','UN',23,'1',3,NULL,'2026-06-04 17:41:49','2026-06-04 17:41:49'),(174,'ART-9','Farinha Trigo T65 1kg (Nacional',NULL,'GERAL','UN',6,'1',3,NULL,'2026-06-04 17:41:49','2026-06-04 17:41:49'),(175,'ART-10','Açúcar Amarelo 1kg (Sidul',NULL,'GERAL','UN',6,'1',3,NULL,'2026-06-04 17:41:49','2026-06-04 17:41:49'),(176,'ART-11','Cacau em Pó 250g (Imperial',NULL,'GERAL','UN',23,'1',3,NULL,'2026-06-04 17:41:49','2026-06-04 17:41:49');
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchaseorderc`
--

DROP TABLE IF EXISTS `purchaseorderc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchaseorderc` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `pONumber` int NOT NULL,
  `supplierCode` int NOT NULL,
  `pODate` date DEFAULT NULL,
  `pOObservation` text COLLATE utf8mb4_unicode_ci,
  `financialDiscount` decimal(14,2) NOT NULL DEFAULT '0.00',
  `totalNet` decimal(14,2) NOT NULL DEFAULT '0.00',
  `totalTax` decimal(14,2) NOT NULL DEFAULT '0.00',
  `totalGross` decimal(14,2) NOT NULL DEFAULT '0.00',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT '0 = Pendente, 1 = Aprovado',
  `created_by` int DEFAULT NULL,
  `updated_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `purchaseorderc_ponumber_unique` (`pONumber`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchaseorderc`
--

LOCK TABLES `purchaseorderc` WRITE;
/*!40000 ALTER TABLE `purchaseorderc` DISABLE KEYS */;
INSERT INTO `purchaseorderc` VALUES (1,1,11,'2026-05-07',NULL,5.00,77.50,17.83,90.33,0,3,NULL,'2026-05-07 20:20:31','2026-05-07 20:20:31'),(2,2,999,'2026-05-14',NULL,0.00,30.00,6.90,36.90,0,3,NULL,'2026-05-14 10:35:34','2026-05-14 10:35:34'),(4,3,1003,'2026-06-04',NULL,0.00,867.50,52.05,919.55,0,3,NULL,'2026-06-04 17:39:01','2026-06-04 17:39:01'),(5,4,1004,'2026-06-04',NULL,0.00,1060.00,133.64,1193.64,0,3,NULL,'2026-06-04 17:43:26','2026-06-04 17:43:26');
/*!40000 ALTER TABLE `purchaseorderc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchaseorderd`
--

DROP TABLE IF EXISTS `purchaseorderd`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchaseorderd` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `pONumber` int NOT NULL,
  `pODateDelivery` date DEFAULT NULL,
  `productCode` varchar(21) COLLATE utf8mb4_unicode_ci NOT NULL,
  `productFamily` varchar(25) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `productUnit` varchar(25) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `taxRateCode` int NOT NULL,
  `quantity` double DEFAULT NULL,
  `deliveryQuantity` double DEFAULT NULL,
  `dicountPercent` double DEFAULT NULL,
  `unitPrice` double DEFAULT NULL,
  `sellingPrice` double DEFAULT NULL,
  `status` tinyint NOT NULL DEFAULT '0' COMMENT '0 = Pendente, 1 = Aprovado',
  `created_by` int DEFAULT NULL,
  `updated_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchaseorderd`
--

LOCK TABLES `purchaseorderd` WRITE;
/*!40000 ALTER TABLE `purchaseorderd` DISABLE KEYS */;
INSERT INTO `purchaseorderd` VALUES (1,1,NULL,'P002','Sumos','L',23,10,3,0,1.5,NULL,0,3,3,'2026-05-07 20:20:31','2026-05-14 08:01:54'),(2,1,NULL,'P002','Sumos','L',23,50,3,0,1.25,NULL,0,3,3,'2026-05-07 20:20:31','2026-05-14 08:01:54'),(3,2,NULL,'P001','Sumos','L',23,10,1,0,2,NULL,0,3,3,'2026-05-14 10:35:34','2026-05-14 10:40:26'),(4,2,NULL,'P002','Sumos','L',23,10,2,0,1,NULL,0,3,3,'2026-05-14 10:35:34','2026-05-14 10:40:26'),(13,3,NULL,'ART-1','GERAL','UN',6,300,0,0,0.79,NULL,0,3,NULL,'2026-06-04 17:39:01','2026-06-04 17:39:01'),(14,3,NULL,'ART-2','GERAL','UN',6,200,0,0,0.55,NULL,0,3,NULL,'2026-06-04 17:39:01','2026-06-04 17:39:01'),(15,3,NULL,'ART-3','GERAL','UN',6,80,0,0,2.35,NULL,0,3,NULL,'2026-06-04 17:39:01','2026-06-04 17:39:01'),(16,3,NULL,'ART-4','GERAL','UN',6,100,0,0,1.99,NULL,0,3,NULL,'2026-06-04 17:39:01','2026-06-04 17:39:01'),(17,3,NULL,'ART-5','GERAL','UN',6,150,0,0,0.89,NULL,0,3,NULL,'2026-06-04 17:39:01','2026-06-04 17:39:01'),(18,4,NULL,'ART-6','GERAL','UN',6,100,0,0,1.45,NULL,0,3,NULL,'2026-06-04 17:43:26','2026-06-04 17:43:26'),(19,4,NULL,'ART-7','GERAL','UN',6,500,0,0,0.28,NULL,0,3,NULL,'2026-06-04 17:43:26','2026-06-04 17:43:26'),(20,4,NULL,'ART-8','GERAL','UN',23,50,0,0,4.8,NULL,0,3,NULL,'2026-06-04 17:43:26','2026-06-04 17:43:26'),(21,4,NULL,'ART-9','GERAL','UN',6,200,0,0,0.99,NULL,0,3,NULL,'2026-06-04 17:43:26','2026-06-04 17:43:26'),(22,4,NULL,'ART-10','GERAL','UN',6,150,0,0,1.1,NULL,0,3,NULL,'2026-06-04 17:43:26','2026-06-04 17:43:26'),(23,4,NULL,'ART-11','GERAL','UN',23,80,0,0,2.15,NULL,0,3,NULL,'2026-06-04 17:43:26','2026-06-04 17:43:26');
/*!40000 ALTER TABLE `purchaseorderd` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('i6INkTwlMf5dZlh2zSTPO72iesgROw0S364k99ef',3,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','YTo1OntzOjY6Il90b2tlbiI7czo0MDoiNDEwU0NUdWZzZ2k0QWV4NjhKQmR0V0lhMnRJZUlkcU84VUJqT3RDUSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mzk6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9wdXJjaGFzZU9yZGVyL29jciI7czo1OiJyb3V0ZSI7czoxNzoicHVyY2hhc2VPcmRlci5vY3IiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aTozO3M6MjM6Im9jcl9wdXJjaGFzZV9vcmRlcl9kYXRhIjthOjU6e3M6ODoic3VwcGxpZXIiO2E6NDp7czo0OiJjb2RlIjtzOjA6IiI7czo0OiJuYW1lIjtzOjIxOiJTQUxTSUNIQVJJQSBCRUlSQSwgU0EiO3M6MzoibmlmIjtzOjk6IjUxNjc4OTAxMiI7czo1OiJmb3VuZCI7YjowO31zOjU6ImxpbmVzIjthOjU6e2k6MDthOjExOntzOjExOiJwcm9kdWN0Q29kZSI7czo3OiJDQVItMDAxIjtzOjExOiJkZXNjcmlwdGlvbiI7czo0MDoiUHJlc3VudG8gSWLDqXJpY28gZmF0aWFkbyAxMDA5IChNb250YWx2YSI7czoxMzoicHJvZHVjdEZhbWlseSI7czo1OiJHRVJBTCI7czoxMToicHJvZHVjdFVuaXQiO3M6MjoiVU4iO3M6MTE6InRheFJhdGVDb2RlIjtpOjY7czo3OiJ0YXhSYXRlIjtkOjY7czo4OiJxdWFudGl0eSI7ZDoxMjA7czo5OiJ1bml0UHJpY2UiO2Q6My45OTtzOjU6ImZvdW5kIjtiOjA7czo3OiJlbmFibGVkIjtiOjE7czo2OiJvY3JSYXciO2E6Njp7czo2OiJjb2RpZ28iO3M6NzoiQ0FSLTAwMSI7czo5OiJkZXNjcmljYW8iO3M6NDA6IlByZXN1bnRvIEliw6lyaWNvIGZhdGlhZG8gMTAwOSAoTW9udGFsdmEiO3M6MTA6InF1YW50aWRhZGUiO2Q6MTIwO3M6MTM6InByZWNvVW5pdGFyaW8iO2Q6My45OTtzOjc6InVuaWRhZGUiO3M6NDoiMyw5OSI7czozOiJpdmEiO2Q6Njt9fWk6MTthOjExOntzOjExOiJwcm9kdWN0Q29kZSI7czo3OiJDQVItMDAyIjtzOjExOiJkZXNjcmlwdGlvbiI7czo0MToiQ2hvdXJpw6dvIGRlIENhcm5lIDMwMGcgKENhc2EgZGEgTWF0YW7Dp2EiO3M6MTM6InByb2R1Y3RGYW1pbHkiO3M6NToiR0VSQUwiO3M6MTE6InByb2R1Y3RVbml0IjtzOjI6IlVOIjtzOjExOiJ0YXhSYXRlQ29kZSI7aTo2O3M6NzoidGF4UmF0ZSI7ZDo2O3M6ODoicXVhbnRpdHkiO2Q6Mi44NTtzOjk6InVuaXRQcmljZSI7ZDoyLjg1O3M6NToiZm91bmQiO2I6MDtzOjc6ImVuYWJsZWQiO2I6MTtzOjY6Im9jclJhdyI7YTo2OntzOjY6ImNvZGlnbyI7czo3OiJDQVItMDAyIjtzOjk6ImRlc2NyaWNhbyI7czo0MToiQ2hvdXJpw6dvIGRlIENhcm5lIDMwMGcgKENhc2EgZGEgTWF0YW7Dp2EiO3M6MTA6InF1YW50aWRhZGUiO2Q6Mi44NTtzOjEzOiJwcmVjb1VuaXRhcmlvIjtkOjIuODU7czo3OiJ1bmlkYWRlIjtzOjQ6IjIuODUiO3M6MzoiaXZhIjtkOjY7fX1pOjI7YToxMTp7czoxMToicHJvZHVjdENvZGUiO3M6NzoiQ0FSLTAwMyI7czoxMToiZGVzY3JpcHRpb24iO3M6MjM6Ikxpbmd1acOnYSBkZWZ1bWFkYSAyNTBnIjtzOjEzOiJwcm9kdWN0RmFtaWx5IjtzOjU6IkdFUkFMIjtzOjExOiJwcm9kdWN0VW5pdCI7czoyOiJVTiI7czoxMToidGF4UmF0ZUNvZGUiO2k6NjtzOjc6InRheFJhdGUiO2Q6NjtzOjg6InF1YW50aXR5IjtkOjIuNDtzOjk6InVuaXRQcmljZSI7ZDoyLjQ7czo1OiJmb3VuZCI7YjowO3M6NzoiZW5hYmxlZCI7YjoxO3M6Njoib2NyUmF3IjthOjY6e3M6NjoiY29kaWdvIjtzOjc6IkNBUi0wMDMiO3M6OToiZGVzY3JpY2FvIjtzOjIzOiJMaW5ndWnDp2EgZGVmdW1hZGEgMjUwZyI7czoxMDoicXVhbnRpZGFkZSI7ZDoyLjQ7czoxMzoicHJlY29Vbml0YXJpbyI7ZDoyLjQ7czo3OiJ1bmlkYWRlIjtzOjQ6IjIuNDAiO3M6MzoiaXZhIjtkOjY7fX1pOjM7YToxMTp7czoxMToicHJvZHVjdENvZGUiO3M6NzoiQ0FSLTAwNCI7czoxMToiZGVzY3JpcHRpb24iO3M6Mzk6IkZpYW1icmUgZGUgUGVydSBmYXRpYWRvIDIwMGcgKENhbXBvZnJpbyI7czoxMzoicHJvZHVjdEZhbWlseSI7czo1OiJHRVJBTCI7czoxMToicHJvZHVjdFVuaXQiO3M6MjoiVU4iO3M6MTE6InRheFJhdGVDb2RlIjtpOjY7czo3OiJ0YXhSYXRlIjtkOjY7czo4OiJxdWFudGl0eSI7ZDoxMDA7czo5OiJ1bml0UHJpY2UiO2Q6Mi4xO3M6NToiZm91bmQiO2I6MDtzOjc6ImVuYWJsZWQiO2I6MTtzOjY6Im9jclJhdyI7YTo2OntzOjY6ImNvZGlnbyI7czo3OiJDQVItMDA0IjtzOjk6ImRlc2NyaWNhbyI7czozOToiRmlhbWJyZSBkZSBQZXJ1IGZhdGlhZG8gMjAwZyAoQ2FtcG9mcmlvIjtzOjEwOiJxdWFudGlkYWRlIjtkOjEwMDtzOjEzOiJwcmVjb1VuaXRhcmlvIjtkOjIuMTtzOjc6InVuaWRhZGUiO3M6NDoiMi4xMCI7czozOiJpdmEiO2Q6Njt9fWk6NDthOjExOntzOjExOiJwcm9kdWN0Q29kZSI7czo3OiJDQVItMDA1IjtzOjExOiJkZXNjcmlwdGlvbiI7czoyNzoiU2FsYW1lIEl0YWxpYW5vIDE1MGcgKE5vYnJlIjtzOjEzOiJwcm9kdWN0RmFtaWx5IjtzOjU6IkdFUkFMIjtzOjExOiJwcm9kdWN0VW5pdCI7czoyOiJVTiI7czoxMToidGF4UmF0ZUNvZGUiO2k6NjtzOjc6InRheFJhdGUiO2Q6NjtzOjg6InF1YW50aXR5IjtkOjMuMjtzOjk6InVuaXRQcmljZSI7ZDozLjI7czo1OiJmb3VuZCI7YjowO3M6NzoiZW5hYmxlZCI7YjoxO3M6Njoib2NyUmF3IjthOjY6e3M6NjoiY29kaWdvIjtzOjc6IkNBUi0wMDUiO3M6OToiZGVzY3JpY2FvIjtzOjI3OiJTYWxhbWUgSXRhbGlhbm8gMTUwZyAoTm9icmUiO3M6MTA6InF1YW50aWRhZGUiO2Q6My4yO3M6MTM6InByZWNvVW5pdGFyaW8iO2Q6My4yO3M6NzoidW5pZGFkZSI7czo0OiIzLjIwIjtzOjM6Iml2YSI7ZDo2O319fXM6MTA6InZhbGlkYXRpb24iO2E6MDp7fXM6MTI6ImRvY3VtZW50RGF0ZSI7czoxMDoiMjAyNi0wNi0wNSI7czoxNDoiZG9jdW1lbnROdW1iZXIiO3M6MTM6Ik5FLTIwMjYtMDkwMDYiO319',1780599733);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stockmovement`
--

DROP TABLE IF EXISTS `stockmovement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stockmovement` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `productCode` varchar(21) COLLATE utf8mb4_unicode_ci NOT NULL,
  `movementType` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'IN / OUT',
  `sourceType` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'GOODS_RECEIPT / DELIVERY_NOTE',
  `sourceId` bigint unsigned DEFAULT NULL,
  `sourceLineId` bigint unsigned DEFAULT NULL,
  `movementDate` date DEFAULT NULL,
  `quantity` double NOT NULL DEFAULT '0',
  `unitCost` double NOT NULL DEFAULT '0',
  `totalCost` double NOT NULL DEFAULT '0',
  `stockBalanceAfter` double NOT NULL DEFAULT '0',
  `averageCostAfter` double NOT NULL DEFAULT '0',
  `created_by` int DEFAULT NULL,
  `updated_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stockmovement`
--

LOCK TABLES `stockmovement` WRITE;
/*!40000 ALTER TABLE `stockmovement` DISABLE KEYS */;
/*!40000 ALTER TABLE `stockmovement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supplier`
--

DROP TABLE IF EXISTS `supplier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `supplier` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code` int NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nif` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `town` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postalCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint NOT NULL DEFAULT '1',
  `created_by` int DEFAULT NULL,
  `updated_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `supplier_code_unique` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supplier`
--

LOCK TABLES `supplier` WRITE;
/*!40000 ALTER TABLE `supplier` DISABLE KEYS */;
INSERT INTO `supplier` VALUES (2,11,'Super-Mecado Dimas','65432187','Rua 3 nº75','rc/ Esq','Faro','8000-325',1,2,2,'2026-04-19 10:04:38','2026-04-19 10:05:11'),(3,2,'Casa ANdrade','6532542198','Rua Andrade Teixeira',NULL,'Portimão',NULL,1,2,NULL,'2026-04-24 18:34:06',NULL),(4,3,'Casa Tijela do Gato','6554879865','Rua dos Gatos 23','rc Esq','Loulé',NULL,1,2,NULL,'2026-04-24 18:35:27',NULL),(5,999,'ACME Supply Co.',NULL,'Rua Principal, 123',NULL,'Amadora','2700-001',1,1,NULL,'2026-05-14 08:23:08','2026-05-14 08:23:08'),(15,1000,'atl antico cash carry lda','502345671','rua das ind ustrias lote 8 4700-000 braga',NULL,NULL,NULL,1,3,NULL,'2026-06-04 10:22:34','2026-06-04 10:22:34'),(16,1001,'cervejaria portuguesa sa','512345678','',NULL,NULL,NULL,1,3,NULL,'2026-06-04 11:36:23','2026-06-04 11:36:23'),(17,1002,'limpex industrial lda','513456789','',NULL,NULL,NULL,1,3,NULL,'2026-06-04 13:25:52','2026-06-04 13:25:52'),(18,1003,'queijaria serrana sa','514567890','',NULL,NULL,NULL,1,3,NULL,'2026-06-04 13:34:34','2026-06-04 13:34:34'),(19,1004,'panificac ao ribeirinha lda','515678901','',NULL,NULL,NULL,1,3,NULL,'2026-06-04 17:41:49','2026-06-04 17:41:49');
/*!40000 ALTER TABLE `supplier` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `taxrate`
--

DROP TABLE IF EXISTS `taxrate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `taxrate` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `taxRateCode` int NOT NULL,
  `descriptionTaxRate` varchar(25) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `taxRate` double NOT NULL,
  `status` tinyint NOT NULL DEFAULT '1',
  `created_by` int DEFAULT NULL,
  `updated_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `taxrate_taxratecode_unique` (`taxRateCode`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `taxrate`
--

LOCK TABLES `taxrate` WRITE;
/*!40000 ALTER TABLE `taxrate` DISABLE KEYS */;
INSERT INTO `taxrate` VALUES (1,23,'Taxa Normal',23,1,2,2,'2026-04-19 15:20:32','2026-04-19 15:20:37'),(2,6,'Taxa Reduzida',6,1,2,2,'2026-04-19 15:20:53','2026-04-19 15:20:37'),(3,13,'Taxa Intermédia',13,1,2,2,'2026-04-19 15:20:53','2026-04-19 15:20:37');
/*!40000 ALTER TABLE `taxrate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `unitmeasure`
--

DROP TABLE IF EXISTS `unitmeasure`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `unitmeasure` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `unit` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unitmeasure_unity_unique` (`unit`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `unitmeasure`
--

LOCK TABLES `unitmeasure` WRITE;
/*!40000 ALTER TABLE `unitmeasure` DISABLE KEYS */;
INSERT INTO `unitmeasure` VALUES (1,'L','2026-04-24 18:29:02',NULL),(2,'S','2026-04-24 18:29:10',NULL),(3,'M','2026-04-24 18:29:22',NULL),(4,'XL','2026-04-24 18:29:31',NULL),(5,'XXL','2026-04-24 18:29:36','2026-04-24 18:29:55'),(6,'UN','2026-05-20 19:56:43','2026-05-20 19:56:43'),(7,'CX','2026-05-23 09:05:35','2026-05-23 09:05:35'),(8,'KG','2026-05-23 09:05:35','2026-05-23 09:05:35'),(9,'SAC','2026-05-23 11:06:54','2026-05-23 11:06:54'),(10,'MOLHO','2026-05-23 11:06:54','2026-05-23 11:06:54');
/*!40000 ALTER TABLE `unitmeasure` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `profile_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (2,'Dario Dourado','dariodourado@gmail.com','2026-04-18 20:29:50','$2y$12$eysNVZs.X7jy4hqPXsjciesJULXqEbH8w/jJxuBESLr8Z/ZCazhki','ddourado',NULL,NULL,'2026-04-18 20:08:33','2026-04-18 20:30:52'),(3,'david','davdua1991@gmail.com','2026-05-07 19:12:19','$2y$12$q4wlle6PQx4soyHFHA4BV.sEcL2zzl7Qjb.TFUk0HvI9JHjUqGjc2','david',NULL,'eaXWX0xuDmOoNyBk1doXUfSqphzkcyjpPaHVFF97wo2qP7sMNHubnkjgK0Vq','2026-05-07 19:11:26','2026-06-04 09:59:06');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'erp4udario'
--

--
-- Dumping routines for database 'erp4udario'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-04 20:08:02
